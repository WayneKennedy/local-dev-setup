#!/bin/bash
# TarkaFlow Skills Installation Script
# Run this from WSL to install skills into your Claude Code environment

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="${HOME}/.claude"
TARKAFLOW_DIR="${CLAUDE_DIR}/tarkaflow"

echo "Installing TarkaFlow skills for Claude Code..."

# Create directory structure
mkdir -p "${CLAUDE_DIR}/skills"
mkdir -p "${CLAUDE_DIR}/commands"
mkdir -p "${TARKAFLOW_DIR}/hooks"

# Copy skills
echo "Installing skills..."
cp -r "${SCRIPT_DIR}/skills/"* "${CLAUDE_DIR}/skills/"

# Copy commands
echo "Installing commands..."
cp -r "${SCRIPT_DIR}/commands/"* "${CLAUDE_DIR}/commands/"

# Copy hooks
echo "Installing hooks..."
cp -r "${SCRIPT_DIR}/hooks/"* "${TARKAFLOW_DIR}/hooks/"
chmod +x "${TARKAFLOW_DIR}/hooks/"*.sh

# Merge hooks config into settings.json
SETTINGS_FILE="${CLAUDE_DIR}/settings.json"

if [[ -f "${SETTINGS_FILE}" ]]; then
    echo "Merging hooks into existing settings.json..."
    # Check if hooks key exists
    if grep -q '"hooks"' "${SETTINGS_FILE}"; then
        echo "WARNING: settings.json already has hooks configured."
        echo "You may need to manually merge ${SCRIPT_DIR}/hooks/hooks.json"
        echo ""
        echo "Add this to your SessionStart hooks array:"
        cat "${SCRIPT_DIR}/hooks/hooks.json" | grep -A 10 '"SessionStart"'
    else
        # Simple merge - add hooks before final closing brace
        # This is naive - for complex settings.json, manual merge is safer
        echo "Adding hooks configuration..."
        # Create backup
        cp "${SETTINGS_FILE}" "${SETTINGS_FILE}.backup"
        # Use jq if available, otherwise warn
        if command -v jq &> /dev/null; then
            jq -s '.[0] * .[1]' "${SETTINGS_FILE}" "${SCRIPT_DIR}/hooks/hooks.json" > "${SETTINGS_FILE}.new"
            mv "${SETTINGS_FILE}.new" "${SETTINGS_FILE}"
        else
            echo "jq not found. Please manually merge hooks.json into settings.json"
            echo "Hooks config location: ${SCRIPT_DIR}/hooks/hooks.json"
        fi
    fi
else
    echo "Creating new settings.json with hooks..."
    cp "${SCRIPT_DIR}/hooks/hooks.json" "${SETTINGS_FILE}"
fi

echo ""
echo "Installation complete!"
echo ""
echo "Installed to:"
echo "  Skills:   ${CLAUDE_DIR}/skills/"
echo "  Commands: ${CLAUDE_DIR}/commands/"
echo "  Hooks:    ${TARKAFLOW_DIR}/hooks/"
echo ""
echo "Available commands:"
echo "  /tarka-assess <CR-ID>  - Assess CR for implementation readiness"
echo ""
echo "Restart Claude Code for changes to take effect."
